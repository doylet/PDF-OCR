"""Agentic document understanding pipeline"""
